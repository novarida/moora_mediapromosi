<?php
namespace App\Models;
use CodeIgniter\Model;

class model_datamedia extends Model
{
    protected $table = 'data_media';

    function __construct()
    {
        $this->db = db_connect();
    }

    function tampildata()
    {
        $dataquery = $this->db->query("select * from data_media");
        return $dataquery->getResult();
    }

    function savedata($table,$data)
    {
        $this->db->table($table)->insert($data);
        return true;
    }

    function editdata($table,$data,$where)
    {
        $this->db->table($table)->update($data,$where);
        return true;
    }

}
