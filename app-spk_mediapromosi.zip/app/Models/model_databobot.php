<?php

namespace App\Models;

use CodeIgniter\Model;

class model_databobot extends Model
{
    protected $table = 'data_bobot';

    function __construct()
    {
        $this->db = db_connect();
    }

    function tampilbobot()
    {
        $dataquery = $this->db->query("select * from data_bobot");
        return $dataquery->getResult();
    }

}
