<?php

namespace App\Models;

use CodeIgniter\Model;

class model_konversi extends Model
{
    protected $table = 'konversi_penilaian';

    function __construct()
    {
        $this->db = db_connect();
    }

    function tampilkonversi()
    {
        $dataquery = $this->db->query("select * from konversi_penilaian");
        return $dataquery->getResult();
    }

}
