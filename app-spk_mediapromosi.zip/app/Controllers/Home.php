<?php

namespace App\Controllers;
use App\Models\model_datamedia;
use App\Models\model_datakriteria;
use App\Models\model_databobot;
use App\Models\model_normalisasi;
use App\Models\model_nilaioptimasi;
use App\Models\model_maxmin;
use App\Models\model_perankingan;
use App\Models\model_keputusan;
use App\Models\model_konversi;

class Home extends BaseController
{
    public function index()
    {
        $this->dashboard();
    }

    public function dashboard()
    {
        echo View('admin_header');
        echo View('admin_nav');
        echo View ('view_dashboard'); 
        echo View('admin_footer');
    }
    
    public function contact()
    {
        echo View('admin_header');
        echo View('admin_nav');
        echo View ('view_contact'); 
        echo View('admin_footer');
    }

    public function viewdatamedia()
    {
        $mb = new model_datamedia();
        $datamedia = $mb->tampildata();
        $data = array('dataMedia'=> $datamedia,);

        echo View('admin_header');
        echo View('admin_nav');
        echo View ('view_datamedia',$data); 
        echo View('admin_footer');
    }
    
    public function viewdatakriteria()
    {
        $mb = new model_datakriteria();
        $datakriteria = $mb->tampilkriteria();
        $data = array('dataKriteria'=> $datakriteria,);
        
        echo View('admin_header');
        echo View('admin_nav');
        echo View ('view_datakriteria',$data); 
        echo View('admin_footer');
    }

    public function viewdatabobot()
    {
        $mb = new model_databobot();
        $databobot = $mb->tampilbobot();
        $data = array('dataBobot'=> $databobot,);
        
        echo View('admin_header');
        echo View('admin_nav');
        echo View ('view_databobot',$data); 
        echo View('admin_footer');
    }

    public function viewdatakonversi()
    {
        $mb = new model_konversi();
        $dataalternatif = $mb->tampilkonversi();
        $data = array('dataAlternatif'=> $dataalternatif,);
        
        echo View('admin_header');
        echo View('admin_nav');
        echo View ('view_datakonversi',$data); 
        echo View('admin_footer');
    }

    public function viewnormalisasi()
    {
        $mb = new model_normalisasi();
        $datanormalisasi = $mb->hitungNormalisasi();
        $data = array('dataNormalisasi' => $datanormalisasi);

        echo View('admin_header');
        echo View('admin_nav');
        echo View('view_normalisasi', $data);
        echo View('admin_footer');
    }

    public function viewnilaioptimasi()
    {
        $mb = new model_nilaioptimasi();
        $dataoptimasi = $mb->tampiloptimasi();
        $data = array('dataOptimasi' => $dataoptimasi, );
        echo View('admin_header');
        echo View('admin_nav');
        echo View('view_nilaioptimasi', $data);
        echo View('admin_footer');
    }

    public function viewmaxmin()
    {
        $mb = new model_maxmin();
        $datamaxmin = $mb->tampilmaxmin();
        $data = array('dataMaxMin' => $datamaxmin);

        echo View('admin_header');
        echo View('admin_nav');
        echo View('view_maxmin', $data);
        echo View('admin_footer');
    }
    
    public function viewranking()
    {
        $mb = new model_perankingan();
        $dataperankingan = $mb->tampilranking();
        $data = array('dataPerankingan' => $dataperankingan);

        echo View('admin_header');
        echo View('admin_nav');
        echo View('view_perankingan', $data);
        echo View('admin_footer');
    }

    public function viewakhir()
    {
        $mb = new model_keputusan();
        $dataakhir = $mb->tampilakhir();
        $data = array('dataAkhir' => $dataakhir);

        echo View('admin_header');
        echo View('admin_nav');
        echo View('view_keputusan', $data);
        echo View('admin_footer');
    }

    public function formtambahmedia()
    {
        echo View('Admin_header');
        echo View('Admin_nav');
        echo View('tambah_datamedia');
        echo View('Admin_footer');
    }

    public function tambahmedia()
    {
        $id_media = $this->request->getPost('id_media');
        $nama_media = $this->request->getPost('nama_media');
        $jumlah = $this->request->getPost('jumlah');
        $pj_media = $this->request->getPost('pj_media');

        $data = ['id_media' => $id_media,
        'nama_media' => $nama_media,
        'jumlah' => $jumlah,
        'pj_media' => $pj_media,];

        $mb = new model_datamedia();
        $datamedia = "data_media";
        $tambah = $mb -> savedata($datamedia,$data);
        return redirect()->to(site_url());

    }

}
