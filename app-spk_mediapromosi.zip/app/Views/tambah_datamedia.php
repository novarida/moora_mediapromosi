<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Form Data Media Promosi</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <style>
    body {
      background-color: #f2f2f2;
    }
    .btn-submit {
      background-color: #4e3d85;
      color: white;
    }
    .btn-view {
      background: none;
      border: none;
      text-decoration: underline;
      cursor: pointer;
    }
    .btn-view:focus {
      outline: none;
    }
  </style>
</head>
<body>
  <div class="container mt-5">
    <div class="row justify-content-center">
      <div class="col-md-6">
        <div class="card">
          <div class="card-header text-center">
            <h2>Form Data Media Promosi</h2>
          </div>
          <div class="card-body">
            <form method="POST" action="<?php echo site_url('Home/tambahmedia') ?>">
              <div class="form-group">
                <input type="text" class="form-control" name="id_media" placeholder="ID Media">
              </div>
              <div class="form-group">
                <input type="text" class="form-control" name="nama_media" placeholder="Nama Media Promosi">
              </div>
              <div class="form-group">
              <input type="text" class="form-control" name="jumlah" placeholder="Jumlah">
              </div>
              <div class="form-group">
                <input type="text" class="form-control" name="pj_media" placeholder="Alamat">
              </div>
              <button type="submit" class="btn btn-submit">Submit</button>
              <a href="<?php echo site_url('Home/viewdatamedia') ?>" class="btn-btn-link">View Data Media</a>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
