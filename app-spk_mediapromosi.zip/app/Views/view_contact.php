<!-- Konten di view_contact.php -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>About Us 🤗</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo site_url('Home/dashboard'); ?>">Home</a></li>
                        <li class="breadcrumb-item active">About Us</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <!-- Informasi kontak -->
            <div class="row">
                <!-- Contact Information -->
                <div class="col-lg-6">
                    <div class="card">
                        <div class="card-header">
                            <div class="row align-items-center">
                                <div class="col-auto">
                                    <h3 class="card-title">
                                        <i class="fas fa-phone text-success"></i> Information About Us
                                    </h3>
                                </div>
                                <div class="col">
                                    <div class="w-100 border-bottom"></div>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <p>Anggota Kelompok:</p>
                            <ul>
                                <li>Nurul Izzah - 210605110005</li>
                                <li>Nova Rahma Yunida Putri - 210605110014</li>
                            </ul>
                            <p>Informasi Lainnya:</p>
                            <ul>
                                <li>SPK Pemilihan Media Promosi Sekolah SMK Airlangga Balikpapan</li>
                                <li>Metode MOORA</li>
                                <li>Praktikum Sistem Informasi D</li>
                                <li>Teknik Informatika</li>
                                <li>Sains dan Teknologi</li>
                                <li>Universitas Islam Negeri Maulana Malik Ibrahim Malang</li>
                            </ul>
                        </div>
                    </div>
                </div>

                <!-- Google Maps -->
                <div class="col-lg-6">
                    <div class="card">
                        <div class="card-header">
                            <div class="row align-items-center">
                                <div class="col-auto">
                                    <h3 class="card-title">
                                        <i class="fas fa-map-marker-alt text-danger"></i> Location
                                    </h3>
                                </div>
                                <div class="col">
                                    <div class="w-100 border-bottom"></div>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <!-- Google Maps Embed API -->
                            <iframe
                                width="100%"
                                height="300"
                                frameborder="0"
                                scrolling="no"
                                marginheight="0"
                                marginwidth="0"
                                src="https://maps.app.goo.gl/LJ3X2djork7FDc9J6"
                            ></iframe>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>
